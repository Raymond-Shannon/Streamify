import React, {useEffect, useState} from 'react';
import {Card, CardContent, CardMedia} from "@mui/material";
import Typography from "@mui/material/Typography";

function InformationCard(props) {

    const [count, setCount] = useState(0);
    const totalCount = props.description; // Final number to reach
    const incrementSpeed = 20; // Milliseconds delay for each increment
    const incrementValue = props.incrementValue || 1; // Amount to increment by

    console.log(props);

    useEffect(() => {
        let timer;
        if (count < totalCount) {
            timer = setInterval(() => {
                setCount((prevCount) => {
                    if (prevCount >= totalCount) {
                        clearInterval(timer); // Stop incrementing when the count reaches totalUsers
                        return totalCount;
                    }
                    return prevCount + incrementValue;
                });
            }, incrementSpeed);
        }

        return () => clearInterval(timer); // Cleanup interval on component unmount
    }, [count, totalCount]);

    return (
        <div>
            <Card sx={{width: 400, background: props.color, color: "white"}}>
                <CardContent>

                    <Typography gutterBottom variant="h5" component="div" sx={{textAlign: "left"}}>
                        {props.children}{props.title}
                    </Typography>
                    <Typography variant="h3">
                        {count < totalCount ? `+${count}` : totalCount}
                    </Typography>
                </CardContent>
            </Card>
        </div>
    );
}

export default InformationCard;